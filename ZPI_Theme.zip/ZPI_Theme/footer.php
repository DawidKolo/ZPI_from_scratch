<footer>
    <p>This is a footer paragraph</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>
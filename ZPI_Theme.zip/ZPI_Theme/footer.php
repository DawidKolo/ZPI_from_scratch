<footer>
    <p>This is a footer paragraph</p>
</footer>
</body>
</html>
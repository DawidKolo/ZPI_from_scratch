<?php get_header(); ?>
    <div class="content-area">
        <main>
            <section class="slide">Slide</section>
            <section class="services">services</section>
            <section class="middle-area">
                <aside class="sidebar">sidebar</aside>
                <div class="news">news</div>
            </section>    
            <section class="map">map</section>
        </main>
    </div>    
<?php get_footer(); ?>   
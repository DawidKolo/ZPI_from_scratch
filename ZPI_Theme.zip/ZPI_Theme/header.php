<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>ZPI_from_scratch</title>
    <?php wp_head(); ?>

</head>
<body <?php body_class(); ?>>
    <p>header paragraph</p>
    <header>
        <section class="top-bar">
            <div class="social-media-icons">Social Icons</div>
            <div class="search">search</div>
        </section>
        <section class="menu-area">
            <section class="logo">Logo</section>
            <nav class="main-menu">Menu</nav>
        </section>
    </header>
</html>